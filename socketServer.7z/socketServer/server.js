const app = require('express')();
const http = require('http').createServer(app);


const io = require('socket.io')(http, {
    cors: {
        origin: "*"
    }
});



app.get('/', (req, res)=> {
    res.send('<h1>Its Server</h1>');
});

http.listen(3000, ()=> {
    console.log('listening on port 3000');
});

io.on('connection', (socket)=> {
    console.log('Client Connected');
    dataUpdate(socket);
});


function dataUpdate(socket) {
  //socket.emit('dataUpdate', Array.from({length: 5}, ()=> Math.floor(Math.random() * 100)));
 
  socket.emit('dataUpdate', [60, 90, 80, 40, 50]);

//    setTimeout(() => {
//     dataUpdate(socket);
//    }, 2000);
}